import React, { useState } from 'react';
import { Search, ShoppingCart, Menu, Star, Clock, Package, Coffee, Wine, Beef, Milk, SprayCan as Spray, Bath } from 'lucide-react';

// Categories for a small market
const categories = [
  { id: 1, name: 'Cervejas/Vinhos', icon: <Wine className="w-6 h-6" />, color: 'bg-purple-100' },
  { id: 2, name: 'Açougue/Congelados', icon: <Beef className="w-6 h-6" />, color: 'bg-red-100' },
  { id: 3, name: 'Mercearia', icon: <Package className="w-6 h-6" />, color: 'bg-yellow-100' },
  { id: 4, name: 'Laticínios', icon: <Milk className="w-6 h-6" />, color: 'bg-blue-100' },
  { id: 5, name: 'Bebidas', icon: <Coffee className="w-6 h-6" />, color: 'bg-orange-100' },
  { id: 6, name: 'Limpeza', icon: <Spray className="w-6 h-6" />, color: 'bg-green-100' },
  { id: 7, name: 'Higiene Pessoal', icon: <Bath className="w-6 h-6" />, color: 'bg-pink-100' }
];

const featuredProducts = [
  {
    id: 1,
    name: 'Cesta Básica Família',
    price: 89.90,
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=500',
    rating: 4.8,
    description: 'Arroz, feijão, óleo, macarrão e mais',
  },
  {
    id: 2,
    name: 'Kit Hortifruti',
    price: 49.90,
    image: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&q=80&w=500',
    rating: 4.9,
    description: 'Frutas e verduras da estação',
  },
];

// Replace with your WhatsApp number
const WHATSAPP_NUMBER = '5511999999999';

function App() {
  const [cartItems, setCartItems] = useState<Array<{
    id: number;
    name: string;
    price: number;
    quantity: number;
  }>>([]);
  const [showCart, setShowCart] = useState(false);
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    address: '',
    paymentMethod: 'Dinheiro',
  });

  const addToCart = (product: typeof featuredProducts[0]) => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => item.id === product.id);
      if (existingItem) {
        return prevItems.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prevItems, { ...product, quantity: 1 }];
    });
  };

  const sendToWhatsApp = () => {
    if (!customerInfo.name || !customerInfo.address) {
      alert('Por favor, preencha seus dados para continuar.');
      return;
    }

    const orderTotal = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
    
    let message = `*Novo Pedido*\n\n`;
    message += `*Cliente:* ${customerInfo.name}\n`;
    message += `*Endereço:* ${customerInfo.address}\n`;
    message += `*Forma de Pagamento:* ${customerInfo.paymentMethod}\n\n`;
    message += `*Pedido:*\n`;
    cartItems.forEach(item => {
      message += `- ${item.quantity}x ${item.name} (R$ ${(item.price * item.quantity).toFixed(2)})\n`;
    });
    message += `\n*Total: R$ ${orderTotal.toFixed(2)}*`;

    const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    
    setCartItems([]);
    setShowCart(false);
    setCustomerInfo({ name: '', address: '', paymentMethod: 'Dinheiro' });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-green-600 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Menu className="h-6 w-6" />
              <h1 className="text-xl font-bold">Mercadinho Brasil</h1>
            </div>
            <div className="relative cursor-pointer" onClick={() => setShowCart(true)}>
              <ShoppingCart className="h-6 w-6" />
              {cartItems.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-yellow-400 text-green-800 text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold">
                  {cartItems.length}
                </span>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Welcome Banner */}
      <div className="bg-green-500 text-white py-3 px-4 text-center text-sm">
        <p>🎉 Entrega grátis para pedidos acima de R$ 100,00 • Peça até às 18h e receba hoje!</p>
      </div>

      {/* Cart Modal */}
      {showCart && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h2 className="text-xl font-semibold mb-4">Seu Carrinho</h2>
            {cartItems.length === 0 ? (
              <p>Seu carrinho está vazio</p>
            ) : (
              <>
                {cartItems.map(item => (
                  <div key={item.id} className="flex justify-between items-center mb-3">
                    <span>{item.quantity}x {item.name}</span>
                    <span>R$ {(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
                <div className="border-t pt-4 mt-4">
                  <h3 className="font-semibold mb-2">Seus Dados</h3>
                  <input
                    type="text"
                    placeholder="Seu nome"
                    className="w-full mb-2 p-2 border rounded"
                    value={customerInfo.name}
                    onChange={(e) => setCustomerInfo(prev => ({ ...prev, name: e.target.value }))}
                  />
                  <input
                    type="text"
                    placeholder="Seu endereço"
                    className="w-full mb-2 p-2 border rounded"
                    value={customerInfo.address}
                    onChange={(e) => setCustomerInfo(prev => ({ ...prev, address: e.target.value }))}
                  />
                  <select
                    className="w-full mb-4 p-2 border rounded"
                    value={customerInfo.paymentMethod}
                    onChange={(e) => setCustomerInfo(prev => ({ ...prev, paymentMethod: e.target.value }))}
                  >
                    <option>Dinheiro</option>
                    <option>Cartão de Crédito</option>
                    <option>Cartão de Débito</option>
                    <option>PIX</option>
                  </select>
                  <button
                    onClick={sendToWhatsApp}
                    className="w-full bg-green-600 text-white py-2 rounded hover:bg-green-700"
                  >
                    Enviar Pedido pelo WhatsApp
                  </button>
                </div>
              </>
            )}
            <button
              onClick={() => setShowCart(false)}
              className="w-full mt-4 bg-gray-100 py-2 rounded hover:bg-gray-200"
            >
              Fechar
            </button>
          </div>
        </div>
      )}

      {/* Search Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="relative">
          <input
            type="text"
            placeholder="O que você está procurando hoje?"
            className="w-full pl-12 pr-4 py-3 rounded-full border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
        </div>
      </div>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Departamentos</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {categories.map((category) => (
            <div
              key={category.id}
              className={`${category.color} rounded-lg p-4 flex flex-col items-center cursor-pointer hover:shadow-md transition-shadow`}
            >
              {category.icon}
              <span className="text-sm font-medium text-gray-700 mt-2">{category.name}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Ofertas do Dia</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {featuredProducts.map((product) => (
            <div key={product.id} className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-100">
              <div className="relative">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-2 right-2 bg-yellow-400 text-green-800 px-2 py-1 rounded-full text-sm font-bold">
                  Oferta!
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-medium text-gray-800">{product.name}</h3>
                <p className="text-sm text-gray-600 mt-1">{product.description}</p>
                <div className="flex items-center mt-2">
                  <Star className="h-4 w-4 text-yellow-400 fill-current" />
                  <span className="ml-1 text-sm text-gray-600">{product.rating}</span>
                </div>
                <div className="mt-3 flex items-baseline">
                  <p className="text-2xl font-bold text-green-600">
                    R$ {product.price.toFixed(2)}
                  </p>
                </div>
                <button 
                  onClick={() => addToCart(product)}
                  className="mt-4 w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors"
                >
                  Adicionar ao Carrinho
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Delivery Info */}
      <section className="bg-white py-6 mt-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="flex items-center justify-center text-center">
              <div>
                <Clock className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <h3 className="font-medium">Entrega Rápida</h3>
                <p className="text-sm text-gray-600">Em até 2 horas</p>
              </div>
            </div>
            <div className="flex items-center justify-center text-center">
              <div>
                <Package className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <h3 className="font-medium">Produtos Frescos</h3>
                <p className="text-sm text-gray-600">Qualidade garantida</p>
              </div>
            </div>
            <div className="flex items-center justify-center text-center">
              <div>
                <ShoppingCart className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <h3 className="font-medium">Atendimento Local</h3>
                <p className="text-sm text-gray-600">Do bairro para o bairro</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default App;